<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer from vendor folder
require_once __DIR__ . '/vendor/autoload.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get and sanitize form data
    $fullName = isset($_POST['fullName']) ? strip_tags(trim($_POST['fullName'])) : '';
    $company = isset($_POST['company']) ? strip_tags(trim($_POST['company'])) : '';
    $email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
    $phone = isset($_POST['phone']) ? strip_tags(trim($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? strip_tags(trim($_POST['message'])) : '';
    
    // Validation
    if (empty($fullName) || empty($email) || empty($phone) || empty($message)) {
        echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid email address']);
        exit;
    }
    
    // Email configuration
    $to = "gaianovatech@gmail.com";          // Where you want to receive messages
    $fromEmail = "gaianovamsl@gmail.com";    // Sender email address
    $fromName = "Gaianova Website Contact";
    $subject = "New Contact from Gaianova: $fullName";
    
    // HTML email body
    $htmlBody = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: Arial, sans-serif; }
            .container { max-width: 600px; margin: 0 auto; }
            .header { background: #0d5f18; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #0d5f18; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Contact Form Submission</h2>
            </div>
            <div class='content'>
                <div class='field'><span class='label'>Name:</span> $fullName</div>
                <div class='field'><span class='label'>Company:</span> " . ($company ?: 'Not provided') . "</div>
                <div class='field'><span class='label'>Email:</span> $email</div>
                <div class='field'><span class='label'>Phone:</span> $phone</div>
                <div class='field'><span class='label'>Message:</span><br>" . nl2br(htmlspecialchars($message)) . "</div>
                <hr>
                <p style='font-size: 12px; color: #888;'>Sent from Gaianova Website on " . date('Y-m-d H:i:s') . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Plain text alternative
    $textBody = "New Contact Form Submission\n";
    $textBody .= "==========================\n\n";
    $textBody .= "Name: $fullName\n";
    $textBody .= "Company: " . ($company ?: 'Not provided') . "\n";
    $textBody .= "Email: $email\n";
    $textBody .= "Phone: $phone\n";
    $textBody .= "Message:\n$message\n\n";
    $textBody .= "Sent from Gaianova Website on " . date('Y-m-d H:i:s');
    
    // Initialize PHPMailer
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';          // Gmail SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'gaianovamsl@gmail.com';   // Your sender email
        $mail->Password   = 'aaerjnsjqqibqxpo';  // Replace with Gmail App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // or PHPMailer::ENCRYPTION_SMTPS (port 465)
        $mail->Port       = 587;                       // TLS port
        
        // Recipients
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($to, 'Gaianova Tech');       // Add recipient
        $mail->addReplyTo($email, $fullName);          // Reply-to = user's email
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = $textBody;
        
        $mail->send();
        echo json_encode(['status' => 'success', 'message' => 'Message sent successfully!']);
        
    } catch (Exception $e) {
        // Log error for debugging (optional)
        error_log("Mailer Error: " . $mail->ErrorInfo);
        echo json_encode(['status' => 'error', 'message' => 'Failed to send message. Please try again later.']);
    }
    
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>